﻿/**
  Autor: Dalton Solano dos Reis
**/

#define CG_Gizmo  // debugar gráfico.
#define CG_OpenGL // render OpenGL.
//#define CG_DirectX // render DirectX.

using System;
using OpenTK;
using OpenTK.Graphics.OpenGL;
using System.Collections.Generic;
using OpenTK.Input;
using CG_Biblioteca;

namespace gcgcg
{
    class Mundo : GameWindow
    {
        private static Mundo instanciaMundo = null;

        private Mundo(int width, int height) : base(width, height) { }

        public static Mundo GetInstance(int width, int height)
        {
            if (instanciaMundo == null)
                instanciaMundo = new Mundo(width, height);
            return instanciaMundo;
        }

        private CameraOrtho camera = new CameraOrtho();
        protected List<Objeto> objetosLista = new List<Objeto>();
        private ObjetoGeometria objetoSelecionado = null;
        private char objetoId = '@';
        private bool bBoxDesenhar = false;
        int mouseX, mouseY;   //TODO: achar método MouseDown para não ter variável Global
        int contador = 1;
        private bool mouseMoverPto = false;
        private SegReta obj_SegReta;
        private Ponto4D obj_Ponto4D;
        private Ponto4D obj_Ponto4D_Z;
        private int angulo = 45;
        private double raio = 100;

        protected override void OnLoad(EventArgs e)
        {
            base.OnLoad(e);
            camera.xmin = -400; camera.xmax = 400; camera.ymin = -400; camera.ymax = 400;

            objetoId = Utilitario.charProximo(objetoId);
            obj_SegReta = new SegReta(objetoId, null, new Ponto4D(0, 0), new Ponto4D(100, 100));
            obj_SegReta.ObjetoCor.CorR = 0;
            obj_SegReta.ObjetoCor.CorG = 0;
            obj_SegReta.ObjetoCor.CorB = 0;
            obj_SegReta.PrimitivaTipo = PrimitiveType.Lines;//PrimitiveType.Lines; 36 linhas = 72 pontos
            obj_SegReta.PrimitivaTamanho = 5;
            objetosLista.Add(obj_SegReta);
            objetoSelecionado = obj_SegReta;

#if CG_OpenGL
            GL.ClearColor(0.5f, 0.5f, 0.5f, 1.0f);
#endif

        }
        protected override void OnUpdateFrame(FrameEventArgs e)
        {
            base.OnUpdateFrame(e);

#if CG_OpenGL
            GL.MatrixMode(MatrixMode.Projection);
            GL.LoadIdentity();
            GL.Ortho(camera.xmin, camera.xmax, camera.ymin, camera.ymax, camera.zmin, camera.zmax);
#endif

        }
        protected override void OnRenderFrame(FrameEventArgs e)
        {
            base.OnRenderFrame(e);

#if CG_OpenGL
            GL.Clear(ClearBufferMask.ColorBufferBit);
            GL.MatrixMode(MatrixMode.Modelview);
            GL.LoadIdentity();
#endif

#if CG_Gizmo
            Sru3D();
#endif

            for (var i = 0; i < objetosLista.Count; i++)
                objetosLista[i].Desenhar();

#if CG_Gizmo
            if (bBoxDesenhar && (objetoSelecionado != null))
                objetoSelecionado.BBox.Desenhar();
#endif

            this.SwapBuffers();
        }

        protected override void OnKeyDown(OpenTK.Input.KeyboardKeyEventArgs e)
        {

            if (e.Key == Key.H)
                Utilitario.AjudaTeclado();
            else if (e.Key == Key.Escape)
                Exit();
            else if (e.Key == Key.Number0)
            {
                Console.WriteLine("--- Objetos / Pontos: ");
                for (var i = 0; i < objetosLista.Count; i++)
                {
                    Console.WriteLine(objetosLista[i]);
                }
            }
            else if (e.Key == Key.Space)
            {
                obj_Ponto4D = new Ponto4D(0,0,0,1);
                obj_Ponto4D_Z = new Ponto4D(0,0,0,1);

                if (contador == 1)
                {
                    obj_SegReta.PrimitivaTipo = PrimitiveType.Lines;
                }
                else if (contador == 2)
                {
                    obj_SegReta.PrimitivaTipo = PrimitiveType.LineLoop;
                }
                else if (contador == 3)
                {
                    obj_SegReta.PrimitivaTipo = PrimitiveType.LineStrip;
                }
                else if (contador == 4)
                {
                    obj_SegReta.PrimitivaTipo = PrimitiveType.Triangles;
                }
                else if (contador == 5)
                {
                    obj_SegReta.PrimitivaTipo = PrimitiveType.TriangleStrip;
                }
                else if (contador == 6)
                {
                    obj_SegReta.PrimitivaTipo = PrimitiveType.TriangleFan;
                }
                else if (contador == 7)
                {
                    obj_SegReta.PrimitivaTipo = PrimitiveType.Quads;
                }
                else if (contador == 8)
                {
                    obj_SegReta.PrimitivaTipo = PrimitiveType.QuadStrip;
                }
                else if (contador == 9)
                {
                    obj_SegReta.PrimitivaTipo = PrimitiveType.Polygon;
                }
                else if (contador == 10)
                {
                    contador = 1;
                    obj_SegReta.PrimitivaTipo = PrimitiveType.Points;
                }

                contador = contador + 1;

            }
            else if (e.Key == Key.Q)
            {
               obj_Ponto4D = new Ponto4D(objetoSelecionado.PontosUltimo());
               objetoSelecionado.PontosRemoverUltimo();
               obj_Ponto4D_Z = new Ponto4D(objetoSelecionado.PontosUltimo());
               objetoSelecionado.PontosRemoverUltimo();

               obj_Ponto4D.X = obj_Ponto4D.X-= 2;

               obj_Ponto4D_Z.X = obj_Ponto4D_Z.X-= 2;

               objetoSelecionado.PontosAdicionar(obj_Ponto4D_Z);
               objetoSelecionado.PontosAdicionar(obj_Ponto4D);

            }
            else if (e.Key == Key.W)
            {
               obj_Ponto4D = new Ponto4D(objetoSelecionado.PontosUltimo());
               objetoSelecionado.PontosRemoverUltimo();
               obj_Ponto4D_Z = new Ponto4D(objetoSelecionado.PontosUltimo());
               objetoSelecionado.PontosRemoverUltimo();

               obj_Ponto4D.X = obj_Ponto4D.X+= 2;

               obj_Ponto4D_Z.X = obj_Ponto4D_Z.X+= 2;

               objetoSelecionado.PontosAdicionar(obj_Ponto4D_Z);
               objetoSelecionado.PontosAdicionar(obj_Ponto4D);
            }
            else if (e.Key == Key.A)
            {
               obj_Ponto4D = new Ponto4D(objetoSelecionado.PontosUltimo());

               obj_Ponto4D.X = obj_Ponto4D.X-= 2;
               obj_Ponto4D.Y = obj_Ponto4D.Y-= 2;

               objetoSelecionado.PontosRemoverUltimo();
               objetoSelecionado.PontosAdicionar(obj_Ponto4D);

                raio -= 2;
            }
            else if (e.Key == Key.S)
            {
               obj_Ponto4D = new Ponto4D(objetoSelecionado.PontosUltimo());

               obj_Ponto4D.X = obj_Ponto4D.X+= 2;
               obj_Ponto4D.Y = obj_Ponto4D.Y+= 2;

               objetoSelecionado.PontosRemoverUltimo();
               objetoSelecionado.PontosAdicionar(obj_Ponto4D);

               raio += 2;
            }
            else if (e.Key == Key.Z)
            {
                obj_Ponto4D = new Ponto4D(0,0,0,1);
                obj_Ponto4D_Z = new Ponto4D(0,0,0,1);

                angulo += 5;

                objetoSelecionado.PontosRemoverUltimo();
                obj_Ponto4D_Z = new Ponto4D(objetoSelecionado.PontosUltimo());

                obj_Ponto4D.X = obj_Ponto4D_Z.X + ((raio * Math.Cos(Math.PI * 45 / 180.0)) * Math.Cos(Math.PI * angulo / 180.0));
                obj_Ponto4D.Y = obj_Ponto4D_Z.Y + ((raio * Math.Cos(Math.PI * 45 / 180.0)) * Math.Sin(Math.PI * angulo / 180.0));

                objetoSelecionado.PontosAdicionar(obj_Ponto4D);
            }
            else if (e.Key == Key.X)
            {
                obj_Ponto4D = new Ponto4D(0,0,0,1);
                obj_Ponto4D_Z = new Ponto4D(0,0,0,1);

                angulo -= 5;

                objetoSelecionado.PontosRemoverUltimo();
                obj_Ponto4D_Z = new Ponto4D(objetoSelecionado.PontosUltimo());

                obj_Ponto4D.X = obj_Ponto4D_Z.X + ((raio * Math.Cos(Math.PI * 45 / 180.0)) * Math.Cos(Math.PI * angulo / 180.0));
                obj_Ponto4D.Y = obj_Ponto4D_Z.Y + ((raio * Math.Cos(Math.PI * 45 / 180.0)) * Math.Sin(Math.PI * angulo / 180.0));

                objetoSelecionado.PontosAdicionar(obj_Ponto4D);
            }
            else if (e.Key == Key.D)
            {
                camera.PanEsquerda();
            }
            else if (e.Key == Key.E) 
            {
                camera.PanDireita();
            }
            else if (e.Key == Key.C)
            {
                camera.PanCima();
            }
            else if (e.Key == Key.B)
            {
                camera.PanBaixo();

            }
            else if (e.Key == Key.I)
            {
                if (camera.xmin < 0 && camera.ymin < 0) 
                { 
                camera.ZoomIn();
                Console.WriteLine("xMin: " + camera.xmin + " - xMax: " + camera.xmax + " yMin: " + camera.ymin + " - yMax: " + camera.ymax);
                }
            }
            else if (e.Key == Key.O)
            {
                if (camera.xmax < 700 && camera.ymax < 700)
                {
                    camera.ZoomOut();
                    Console.WriteLine("xMin: " + camera.xmin + " - xMax: " + camera.xmax + " yMin: " + camera.ymin + " - yMax: " + camera.ymax);
                }
                
            }
#if CG_Gizmo
            else if (e.Key == Key.Number9)
                bBoxDesenhar = !bBoxDesenhar;
#endif
            else if (e.Key == Key.V)
                mouseMoverPto = !mouseMoverPto;//TODO: falta atualizar a BBox do objeto
            else
                Console.WriteLine(" __ Tecla não implementada.");
        }

        //TODO: não está considerando o NDC
        protected override void OnMouseMove(MouseMoveEventArgs e)
        {
            mouseX = e.Position.X; mouseY = 600 - e.Position.Y; // Inverti eixo Y
            if (mouseMoverPto && (objetoSelecionado != null))
            {
                objetoSelecionado.PontosUltimo().X = mouseX;
                objetoSelecionado.PontosUltimo().Y = mouseY;
            }
        }

#if CG_Gizmo
        private void Sru3D()
        {
#if CG_OpenGL
            GL.LineWidth(1);
            GL.Begin(PrimitiveType.Lines);

            GL.Color3(Convert.ToByte(255), Convert.ToByte(0), Convert.ToByte(0));
            GL.Vertex3(0, 0, 0); GL.Vertex3(200, 0, 0);

            GL.Color3(Convert.ToByte(0), Convert.ToByte(255), Convert.ToByte(0));
            GL.Vertex3(0, 0, 0); GL.Vertex3(0, 200, 0);
            GL.End();
#endif
        }
#endif
    }
    class Program
    {
        static void Main(string[] args)
        {
            Mundo window = Mundo.GetInstance(600, 600);
            window.Title = "CG_N2";
            window.Run(1.0 / 60.0);
        }
    }
}
