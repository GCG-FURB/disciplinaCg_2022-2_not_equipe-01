﻿using OpenTK.Graphics.OpenGL;
using CG_Biblioteca;
using System;

namespace gcgcg
{
    internal class Circulo : ObjetoGeometria
    {
        public static Ponto4D GerarPtosCirculo(double angulo, double raio)
        {
            Ponto4D pto = new Ponto4D();
            pto.X = (raio * Math.Cos(Math.PI * angulo / 180.0));
            pto.Y = (raio * Math.Sin(Math.PI * angulo / 180.0));
            pto.Z = 0;
            return (pto);
        }

        public static double GerarPtosCirculoSimetrico(double raio)
        {
            return (raio * Math.Cos(Math.PI * 45 / 180.0));
        }

        public Circulo(char rotulo, Objeto paiRef, Ponto4D ptoCentro, double raio) : base(rotulo, paiRef)
        {

            Ponto4D v_PontoCirculo;

            for (int i = 0; i < 360; i += 5) 
            { 
                v_PontoCirculo = GerarPtosCirculo(i,GerarPtosCirculoSimetrico(raio));

                base.PontosAdicionar( new Ponto4D(ptoCentro.X + v_PontoCirculo.X, ptoCentro.Y + v_PontoCirculo.Y));

            }
        }

        protected override void DesenharObjeto()
        {
            GL.Begin(base.PrimitivaTipo);
            foreach (Ponto4D pto in pontosLista)
            {
                GL.Vertex2(pto.X, pto.Y);
            }
            GL.End();
        }
    }
}
