﻿/**
  Autor: Dalton Solano dos Reis
**/

#define CG_Gizmo  // debugar gráfico.
#define CG_OpenGL // render OpenGL.
//#define CG_DirectX // render DirectX.

using System;
using OpenTK;
using OpenTK.Graphics.OpenGL;
using System.Collections.Generic;
using OpenTK.Input;
using CG_Biblioteca;

namespace gcgcg
{
    class Mundo : GameWindow
    {
        private static Mundo instanciaMundo = null;

        private Mundo(int width, int height) : base(width, height) { }

        public static Mundo GetInstance(int width, int height)
        {
            if (instanciaMundo == null)
                instanciaMundo = new Mundo(width, height);
            return instanciaMundo;
        }

        private CameraOrtho camera = new CameraOrtho();
        protected List<Objeto> objetosLista = new List<Objeto>();
        private ObjetoGeometria objetoSelecionado = null;
        private char objetoId = '@';
        private bool bBoxDesenhar = false;
        int mouseX, mouseY;   //TODO: achar método MouseDown para não ter variável Global
        private bool mouseMoverPto = false;
        private Circulo obj_Circulo;

        protected override void OnLoad(EventArgs e)
        {
            base.OnLoad(e);
            camera.xmin = -300; camera.xmax = 300; camera.ymin = -300; camera.ymax = 300;
            objetoId = Utilitario.charProximo(objetoId);//--------Y, X
            obj_Circulo = new Circulo(objetoId, null, new Ponto4D(0, 0), 100);
            obj_Circulo.ObjetoCor.CorR = 0;
            obj_Circulo.ObjetoCor.CorG = 0;
            obj_Circulo.ObjetoCor.CorB = 0;
            obj_Circulo.PrimitivaTipo = PrimitiveType.Points;//PrimitiveType.Lines; 36 linhas = 72 pontos
            obj_Circulo.PrimitivaTamanho = 5;
            objetosLista.Add(obj_Circulo);
            objetoSelecionado = obj_Circulo;

#if CG_OpenGL
            GL.ClearColor(1.0f, 1.0f, 1.0f, 1.0f);
#endif

        }
        protected override void OnUpdateFrame(FrameEventArgs e)
        {
            base.OnUpdateFrame(e);

#if CG_OpenGL
            GL.MatrixMode(MatrixMode.Projection);
            GL.LoadIdentity();
            GL.Ortho(camera.xmin, camera.xmax, camera.ymin, camera.ymax, camera.zmin, camera.zmax);
#endif

        }
        protected override void OnRenderFrame(FrameEventArgs e)
        {
            base.OnRenderFrame(e);

#if CG_OpenGL
            GL.Clear(ClearBufferMask.ColorBufferBit);
            GL.MatrixMode(MatrixMode.Modelview);
            GL.LoadIdentity();
#endif

#if CG_Gizmo
            Sru3D();
#endif

            for (var i = 0; i < objetosLista.Count; i++)
                objetosLista[i].Desenhar();

#if CG_Gizmo
            if (bBoxDesenhar && (objetoSelecionado != null))
                objetoSelecionado.BBox.Desenhar();
#endif

            this.SwapBuffers();
        }

        protected override void OnKeyDown(OpenTK.Input.KeyboardKeyEventArgs e)
        {
            if (e.Key == Key.H)
                Utilitario.AjudaTeclado();
            else if (e.Key == Key.Escape)
                Exit();
            else if (e.Key == Key.Number0)
            {
                Console.WriteLine("--- Objetos / Pontos: ");
                for (var i = 0; i < objetosLista.Count; i++)
                {
                    Console.WriteLine(objetosLista[i]);
                }
            }
            else if (e.Key == Key.E)
            {
                camera.PanEsquerda();
            }
            else if (e.Key == Key.D) 
            {
                camera.PanDireita();
            }
            else if (e.Key == Key.C)
            {
                camera.PanCima();
            }
            else if (e.Key == Key.B)
            {
                camera.PanBaixo();

            }
            else if (e.Key == Key.I)
            {
                if (camera.xmin < 0 && camera.ymin < 0) 
                { 
                camera.ZoomIn();
                Console.WriteLine("xMin: " + camera.xmin + " - xMax: " + camera.xmax + " yMin: " + camera.ymin + " - yMax: " + camera.ymax);
                }
            }
            else if (e.Key == Key.O)
            {
                if (camera.xmax < 700 && camera.ymax < 700)
                {
                    camera.ZoomOut();
                    Console.WriteLine("xMin: " + camera.xmin + " - xMax: " + camera.xmax + " yMin: " + camera.ymin + " - yMax: " + camera.ymax);
                }
                
            }
#if CG_Gizmo
            else if (e.Key == Key.O)
                bBoxDesenhar = !bBoxDesenhar;
#endif
            else if (e.Key == Key.V)
                mouseMoverPto = !mouseMoverPto;//TODO: falta atualizar a BBox do objeto
            else
                Console.WriteLine(" __ Tecla não implementada.");
        }

        //TODO: não está considerando o NDC
        protected override void OnMouseMove(MouseMoveEventArgs e)
        {
            mouseX = e.Position.X; mouseY = 600 - e.Position.Y; // Inverti eixo Y
            if (mouseMoverPto && (objetoSelecionado != null))
            {
                objetoSelecionado.PontosUltimo().X = mouseX;
                objetoSelecionado.PontosUltimo().Y = mouseY;
            }
        }

#if CG_Gizmo
        private void Sru3D()
        {
#if CG_OpenGL
            GL.LineWidth(1);
            GL.Begin(PrimitiveType.Lines);

            GL.Color3(Convert.ToByte(255), Convert.ToByte(0), Convert.ToByte(0));
            GL.Vertex3(0, 0, 0); GL.Vertex3(200, 0, 0);

            GL.Color3(Convert.ToByte(0), Convert.ToByte(255), Convert.ToByte(0));
            GL.Vertex3(0, 0, 0); GL.Vertex3(0, 200, 0);
            GL.End();
#endif
        }
#endif
    }
    class Program
    {
        static void Main(string[] args)
        {
            Mundo window = Mundo.GetInstance(600, 600);
            window.Title = "CG_N2";
            window.Run(1.0 / 60.0);
        }
    }
}
