﻿using OpenTK.Graphics.OpenGL;
using CG_Biblioteca;
using System;

namespace gcgcg
{
    internal class Circulo : ObjetoGeometria
    {
        Ponto4D V_novo_ponto = new Ponto4D(0,0,0,1);

        public Circulo(char rotulo, Objeto paiRef, Ponto4D ptoCentro, double raio) : base(rotulo, paiRef)
        {

            for (int i = 0; i < 360; i = i + 5) 
            {
                V_novo_ponto = Matematica.GerarPtosCirculo(i,Matematica.GerarPtosCirculoSimetrico(raio));
                base.PontosAdicionar(new Ponto4D(V_novo_ponto.X + ptoCentro.X,V_novo_ponto.Y + ptoCentro.Y));

            }
        }

        protected override void DesenharObjeto()
        {
            GL.Begin(base.PrimitivaTipo);
            foreach (Ponto4D pto in pontosLista)
            {
                GL.Vertex2(pto.X, pto.Y);
            }
            GL.End();
        }
    }
}
